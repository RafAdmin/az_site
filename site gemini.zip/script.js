document.addEventListener('DOMContentLoaded', function () {
  //  Form de teste grátis
  const testButtons = document.querySelectorAll('a[href="#teste-gratis"]');
  testButtons.forEach(button => {
      button.addEventListener('click', function (event) {
          event.preventDefault(); // Impede o comportamento padrão do link
          
          // Crie o formulário (você pode estilizar isso no CSS também)
          const formOverlay = document.createElement('div');
          formOverlay.classList.add('form-overlay');
          
          const formContainer = document.createElement('div');
          formContainer.classList.add('form-container');

          const form = document.createElement('form');
          form.innerHTML = `
              <h2>Teste Grátis AutoZapi</h2>
              <label for="name">Nome:</label>
              <input type="text" id="name" name="name" required>

              <label for="email">Email:</label>
              <input type="email" id="email" name="email" required>

              <label for="phone">Telefone:</label>
              <input type="tel" id="phone" name="phone" required>

              <button type="submit" class="cta-button">Solicitar Teste Grátis</button>
              <button type="button" class="close-form">Fechar</button>
          `;

          formContainer.appendChild(form);
          formOverlay.appendChild(formContainer);
          document.body.appendChild(formOverlay);

         // Evento de fechamento do formulário
          const closeButton = form.querySelector('.close-form');
          closeButton.addEventListener('click', function() {
             formOverlay.remove();
           });


          // Form Handling (substitua com sua lógica de envio)
          form.addEventListener('submit', function (e) {
              e.preventDefault();

              const name = document.getElementById('name').value;
              const email = document.getElementById('email').value;
              const phone = document.getElementById('phone').value;

              // Aqui você pode adicionar a lógica para enviar dados (ex: para um servidor)
              console.log('Formulário enviado:', {name, email, phone});

              alert('Obrigado! Enviaremos um email com os dados para teste grátis.');
              formOverlay.remove(); // Fechar o formulário após envio
          });
      });
  });
});